// Gets the specific CSS-file.
specificStyle.href = chrome.runtime.getURL('injection-styling/blog-page.css');

styles.addSpecificStyle(specificStyle);
