// Gets the spesific CSS-file
spesificStyle.href = chrome.runtime.getURL('injection-styling/news-and-videos-page.css');

styles.push(spesificStyle);
