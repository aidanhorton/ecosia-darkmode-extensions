// Gets the spesific CSS-file
spesificStyle.href = chrome.runtime.getURL('injection-styling/images-page.css');

styles.push(spesificStyle);
