// Gets the spesific CSS-file
spesificStyle.href = chrome.runtime.getURL('injection-styling/shopping-page.css');

styles.push(spesificStyle);
