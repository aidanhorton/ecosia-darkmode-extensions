// Gets the specific CSS-file
specificStyle.href = chrome.runtime.getURL('injection-styling/home-page.css');

styles.push(specificStyle);