// Gets the spesific CSS-file
spesificStyle.href = chrome.runtime.getURL('injection-styling/search-page.css');

styles.push(spesificStyle);
