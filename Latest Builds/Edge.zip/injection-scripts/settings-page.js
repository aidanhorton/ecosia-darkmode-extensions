// Gets the spesific CSS-file
spesificStyle.href = chrome.runtime.getURL('injection-styling/settings-page.css');

styles.push(spesificStyle);
