// Gets the spesific CSS-file
spesificStyle.href = chrome.runtime.getURL('injection-styling/home-page.css');

styles.push(spesificStyle);