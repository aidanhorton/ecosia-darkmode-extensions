// Gets the spesific CSS-file
spesificStyle.href = chrome.runtime.getURL('injection-styling/login-page.css');

styles.push(spesificStyle);
