// Gets the specific CSS-file.
specificStyle.href = chrome.runtime.getURL('injection-styling/news-and-videos-page.css');

styles.addSpecificStyle(specificStyle);
