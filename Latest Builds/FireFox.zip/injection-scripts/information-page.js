// Gets the specific CSS-file.
specificStyle.href = chrome.runtime.getURL('injection-styling/information-page.css');

styles.addSpecificStyle(specificStyle);
