// Gets the spesific CSS-file
spesificStyle.href = chrome.runtime.getURL('injection-styling/information-page.css');

styles.push(spesificStyle);
