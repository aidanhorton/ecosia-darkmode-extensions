// Gets the specific CSS-file
specificStyle.href = chrome.runtime.getURL('injection-styling/settings-page.css');

styles.push(specificStyle);
