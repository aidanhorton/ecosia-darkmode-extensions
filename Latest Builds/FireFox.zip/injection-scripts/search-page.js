// Gets the specific CSS-file.
specificStyle.href = chrome.runtime.getURL('injection-styling/search-page.css');

styles.addSpecificStyle(specificStyle);
